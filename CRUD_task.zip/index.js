let locals = localStorage.getItem('recipes');
if(locals===null) { 
    localStorage.setItem('a1',JSON.stringify({name:'Spaghetti',how:['Noodles','Tomato Sauce','(Optional) Meatballs'],id:1})); 
    localStorage.setItem('recipes',JSON.stringify(['a1']));
    window.location.reload();
}
let r = JSON.parse(locals);
var next=parseInt(r[r.length-1].substr(1))+1;

function renderRecipes(retr) {
	let rec = localStorage.getItem(retr);
	let which=JSON.parse(rec);
	let ingredients='';
	let num = which.id;
	which.how.forEach(ingredient=>{ingredients+= `<tr><td style=background-color:white;width:100%;paddding:5px;>${ingredient}</td></tr>`;});
	let full=`<details 
	 class=recipe id=${'r'+num}>
     <summary>${which.name}</summary>
     <p class=details>
     <b>Ingredients</b>
	 <span class=ruler> </span>
	 <table width=100% cellspacing=0 cellpadding=7>${ingredients}</table>
	 <button class=del onclick=del(${num})>Delete</button>
	 <button class=ed onclick=load('Edit',${num})> Edit</button>
     </p>
    </details>`;
	// nie chciałem zamulać tak prostej aplikacji JSX'em ani bawić się ani bawić się z React.createElement Hell, więc zrobiłem klasycznie:
	document.getElementById('overall').innerHTML+=full;
}

function updateR() {
	let locals = localStorage.getItem('recipes');
	document.getElementById('overall').innerHTML='';
	let myRec = JSON.parse(locals);
	myRec.forEach(local=>{ 
		renderRecipes(local);});
}

updateR();

function load(action, id=0) {
	let list=''; 
	let header='';
	let store;
	if(id!=0) {
		store=localStorage.getItem('a'+id);
		header=JSON.parse(store).name;
		list=JSON.parse(store).how;
	} else id=next;
	let popup = `<article id=shutter>
	 <section id=${id} class=altering>
	  <big>${action} Recipe</big>
	  <span onclick=unload()>x</span><hr>
      Recipe<br><form><input value=${header}><br>
      Ingredients<br><textarea rows=2 cols=40>${list}</textarea><hr>
      <button class=act onclick=act(${id},'${action}')>${action} Recipe</button>
      <button onclick=unload() class=ed>Close</button>
     </section></article>`;
	document.getElementsByTagName('body')[0].innerHTML+=popup;
}

function unload() {
	let e = document.getElementById('shutter');
	e.parentNode.removeChild(e);
}

function act(id,action) { 
	let list = document.getElementsByTagName('textarea')[0].value.split(',');
	let title = document.getElementsByTagName('input')[0].value;
	if(list==''||title=='') {
		alert('Wypełnij dane przed wstawieniem!');
		return;
	}
	if(id==1) { 
		alert('Stick to your own recipes'); 
		return;
	}
	let ob = { name:title, how:list, id:id} 
	localStorage.setItem('a'+id,JSON.stringify(ob));
	if(action=='Add') { 
		let p = JSON.parse(localStorage.getItem('recipes'));
		p.push('a'+id);
		localStorage.setItem('recipes',JSON.stringify(p));
		next++;
	}
	updateR();
}

function del(id) {
	if(id==1) { 
		alert('Stick to your own recipes');
		return;
	}
	let p = JSON.parse(localStorage.getItem('recipes'));
	let w = p.filter((item)=>{return item!='a'+id;}); 
	localStorage.setItem('recipes',JSON.stringify(w));
	updateR();
}